import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { admin } from "./db";
export async function authClient() {
  const c = await cookies();
  return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { cookies: { getAll: () => c.getAll(), setAll: (l) => { try { l.forEach(({ name, value, options }) => c.set(name, value, options)); } catch {} } } });
}
// Every admin page and action calls this: must be signed in AND listed in admin_users.
export async function requireAdmin() {
  const { data: { user } } = await (await authClient()).auth.getUser();
  if (!user) redirect("/admin/login");
  const { data } = await admin().from("admin_users").select("user_id").eq("user_id", user.id).maybeSingle();
  if (!data) redirect("/admin/login?e=forbidden");
  return user;
}
