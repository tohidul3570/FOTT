import { createClient } from "@supabase/supabase-js";
export const db = () => createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, { auth: { persistSession: false } });
export const admin = () => createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } });
export const TZ = "Europe/London";
export const ukTime = (iso: string) => new Intl.DateTimeFormat("en-GB", { timeZone: TZ, hour: "2-digit", minute: "2-digit" }).format(new Date(iso));
export const ukDay = (d: Date) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ }).format(d); // YYYY-MM-DD
export const ukLong = (iso: string) => new Intl.DateTimeFormat("en-GB", { timeZone: TZ, weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date(iso));
// UK-day bounds as UTC instants (handles GMT/BST)
export function dayRange(ymd: string) {
  const off = (d: Date) => { const p = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, timeZoneName: "shortOffset" }).formatToParts(d).find(x => x.type === "timeZoneName")!.value; const m = p.match(/GMT([+-]\d+)?/); return m?.[1] ? parseInt(m[1]) : 0; };
  const noon = new Date(ymd + "T12:00:00Z"); const o = off(noon);
  const s = new Date(new Date(ymd + "T00:00:00Z").getTime() - o * 36e5);
  return { from: s.toISOString(), to: new Date(s.getTime() + 864e5).toISOString() };
}
export const FIXTURE_SELECT = "id,slug,kickoff,status,home_score,away_score,venue,competition:competitions(slug,name,logo,priority),home:teams!fixtures_home_id_fkey(slug,name,logo),away:teams!fixtures_away_id_fkey(slug,name,logo),broadcasts:fixture_broadcasts(channel_name,coverage,status,broadcaster:broadcasters(slug,name,logo))";
