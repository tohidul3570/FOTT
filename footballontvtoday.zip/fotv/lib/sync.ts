import { admin } from "./db";
const slug = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
let calls = 0;
async function api(path: string) {
  for (let i = 0; i < 3; i++) {
    calls++;
    const r = await fetch("https://v3.football.api-sports.io" + path, { headers: { "x-apisports-key": process.env.API_FOOTBALL_KEY! }, next: { revalidate: 3600 } });
    if (r.status === 429) { await new Promise(r => setTimeout(r, 2000 * (i + 1))); continue; }
    if (!r.ok) throw new Error(`API ${r.status} ${path}`);
    const j = await r.json();
    if (j.errors && Object.keys(j.errors).length) throw new Error(JSON.stringify(j.errors));
    return j.response as any[];
  }
  throw new Error("Rate limited: " + path);
}
export async function syncFixtures() {
  const sb = admin(); let upserted = 0, resched = 0; const touched = new Set<string>(); let err: string | null = null;
  const days = Number(process.env.SYNC_DAYS ?? 45); const from = new Date(), to = new Date(Date.now() + days * 864e5);
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  const { data: comps } = await sb.from("competitions").select("*").eq("enabled", true);
  for (const c of comps ?? []) {
    try {
      const rows = await api(`/fixtures?league=${c.api_id}&season=${c.season}&from=${iso(from)}&to=${iso(to)}`);
      for (const f of rows) {
        const ids: Record<string, number> = {};
        for (const side of ["home", "away"] as const) {
          const t = f.teams[side];
          const { data } = await sb.from("teams").upsert({ api_id: t.id, slug: slug(t.name), name: t.name, logo: t.logo, updated_at: new Date().toISOString() }, { onConflict: "api_id" }).select("id").single();
          ids[side] = data!.id;
        }
        const fslug = `${slug(f.teams.home.name)}-vs-${slug(f.teams.away.name)}-${f.fixture.date.slice(0, 10)}`;
        const { data: ex } = await sb.from("fixtures").select("id,slug,kickoff,manual_override").eq("api_id", f.fixture.id).maybeSingle();
        if (ex?.manual_override) continue; // keep manual corrections
        if (ex && new Date(ex.kickoff).getTime() !== new Date(f.fixture.date).getTime()) resched++;
        const row: any = { api_id: f.fixture.id, competition_id: c.id, home_id: ids.home, away_id: ids.away, kickoff: f.fixture.date, status: f.fixture.status.short, home_score: f.goals.home, away_score: f.goals.away, venue: f.fixture.venue?.name, updated_at: new Date().toISOString() };
        row.slug = ex?.slug ?? fslug; // stable URL even when rescheduled
        const { error } = await sb.from("fixtures").upsert(row, { onConflict: "api_id" }); // never touches fixture_broadcasts
        if (error) throw error; upserted++; touched.add(c.slug);
      }
    } catch (e: any) { err = (err ? err + "; " : "") + `${c.name}: ${e.message ?? e}`; }
  }
  await sb.from("sync_logs").insert({ ok: !err, fixtures_upserted: upserted, rescheduled: resched, api_calls: calls, error: err });
  return { ok: !err, upserted, resched, calls, err, comps: [...touched] };
}
