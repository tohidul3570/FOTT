import { notFound } from "next/navigation";
import Link from "next/link";
import { db, ukTime, ukLong, FIXTURE_SELECT } from "@/lib/db";
export const revalidate = 600;
const get = async (slug: string) => (await db().from("fixtures").select(FIXTURE_SELECT).eq("slug", slug).eq("published", true).maybeSingle()).data as any;
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const f = await get((await params).slug); if (!f) return {};
  const t = `${f.home.name} vs ${f.away.name} on TV – ${f.competition.name}`;
  return { title: t, description: `${f.home.name} v ${f.away.name}, ${ukLong(f.kickoff)}, ${ukTime(f.kickoff)} UK time. See UK TV coverage.`, alternates: { canonical: `/match/${f.slug}` }, openGraph: { title: t } };
}
export default async function Match({ params }: { params: Promise<{ slug: string }> }) {
  const f = await get((await params).slug); if (!f) notFound();
  const conf = f.broadcasts.filter((b: any) => b.status === "confirmed");
  const ld = { "@context": "https://schema.org", "@type": "SportsEvent", name: `${f.home.name} vs ${f.away.name}`, startDate: f.kickoff, homeTeam: { "@type": "SportsTeam", name: f.home.name }, awayTeam: { "@type": "SportsTeam", name: f.away.name }, ...(f.venue && { location: { "@type": "Place", name: f.venue } }) };
  return (<article>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
    <nav aria-label="Breadcrumb" className="text-sm text-ink/70"><Link href="/">Home</Link> / <Link href={`/${f.competition.slug}-on-tv`}>{f.competition.name}</Link></nav>
    <h1 className="mt-3 text-3xl font-extrabold">{f.home.name} vs {f.away.name}</h1>
    <p className="mt-1">{f.competition.name} · {ukLong(f.kickoff)}</p>
    <p className="mt-3 text-2xl font-bold text-pitch">{ukTime(f.kickoff)} UK time</p>
    {f.venue && <p className="mt-1 text-ink/70">Stadium: {f.venue}</p>}
    <h2 className="mt-6 text-xl font-bold">Where to watch</h2>
    {conf.length ? <ul className="mt-2 space-y-2">{conf.map((b: any, i: number) => <li key={i} className="rounded-lg border border-line p-3"><Link href={`/${b.broadcaster.slug}`} className="font-semibold hover:text-pitch">{b.channel_name ?? b.broadcaster.name}</Link>{b.coverage && <span className="text-ink/70"> – {b.coverage}</span>}</li>)}</ul> : <p className="mt-2 rounded-lg bg-mist p-4">TV coverage not confirmed.</p>}
  </article>);
}
