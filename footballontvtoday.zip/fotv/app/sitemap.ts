import { db } from "@/lib/db";
export default async function sitemap() {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://footballontvtoday.com"; const sb = db();
  const [{ data: c }, { data: f }] = await Promise.all([sb.from("competitions").select("slug").eq("enabled", true), sb.from("fixtures").select("slug,updated_at").eq("published", true).gte("kickoff", new Date().toISOString()).limit(5000)]);
  return [{ url: base }, ...(c ?? []).map(x => ({ url: `${base}/${x.slug}-on-tv` })), ...(f ?? []).map(x => ({ url: `${base}/match/${x.slug}`, lastModified: x.updated_at }))];
}
