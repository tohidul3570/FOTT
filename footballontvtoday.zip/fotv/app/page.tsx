import Link from "next/link";
import { db, dayRange, ukDay, FIXTURE_SELECT } from "@/lib/db";
import { Listings } from "./components";
export const revalidate = 300;
export const metadata = { title: "Football on TV Today – UK Kick-off Times & Channels" };
const addDays = (ymd: string, n: number) => new Date(new Date(ymd + "T12:00:00Z").getTime() + n * 864e5).toISOString().slice(0, 10);
export default async function Home({ searchParams }: { searchParams: Promise<{ d?: string; c?: string }> }) {
  const sp = await searchParams; const today = ukDay(new Date());
  let day = sp.d === "tomorrow" ? addDays(today, 1) : sp.d === "yesterday" ? addDays(today, -1) : /^\d{4}-\d{2}-\d{2}$/.test(sp.d ?? "") ? sp.d! : today;
  const { from, to } = dayRange(day); const sb = db();
  const { data: comps } = await sb.from("competitions").select("slug,name").eq("enabled", true).order("priority");
  let q = sb.from("fixtures").select(FIXTURE_SELECT).eq("published", true).gte("kickoff", from).lt("kickoff", to).order("kickoff");
  const cid = comps?.find(c => c.slug === sp.c); if (cid) { const { data: c } = await sb.from("competitions").select("id").eq("slug", sp.c!).single(); q = q.eq("competition_id", c!.id); }
  const { data: fixtures, error } = await q;
  const dow = (n: number) => { const d = new Date(today + "T12:00:00Z"); return addDays(today, (n - d.getUTCDay() + 7) % 7); };
  const tabs: [string, string][] = [["Yesterday", addDays(today, -1)], ["Today", today], ["Tomorrow", addDays(today, 1)], ["Saturday", dow(6)], ["Sunday", dow(0)]];
  const href = (d: string, c?: string) => `/?d=${d}${c ? `&c=${c}` : ""}`;
  return (<>
    <h1 className="text-3xl font-extrabold sm:text-4xl">Football on TV Today</h1>
    <p className="mt-2 max-w-2xl text-ink/80">Find out which football matches are on TV today in the UK, including kick-off times, live broadcasters and upcoming fixtures.</p>
    <nav aria-label="Dates" className="mt-5 flex flex-wrap items-center gap-2">
      {tabs.map(([l, d]) => <Link key={l} href={href(d, sp.c)} className={`rounded-full border px-4 py-1.5 text-sm font-medium ${d === day ? "bg-pitch border-pitch text-white" : "border-line hover:border-pitch"}`}>{l}</Link>)}
      <form className="flex gap-2"><input type="date" name="d" defaultValue={day} className="rounded-full border border-line px-3 py-1.5 text-sm" aria-label="Pick a date" /><button className="rounded-full bg-ink px-4 py-1.5 text-sm text-white">Go</button></form>
    </nav>
    <nav aria-label="Competitions" className="mt-3 flex flex-wrap gap-2 text-sm">
      <Link href={href(day)} className={`rounded px-2 py-1 ${!sp.c ? "bg-mist font-semibold" : ""}`}>All</Link>
      {comps?.map(c => <Link key={c.slug} href={href(day, c.slug)} className={`rounded px-2 py-1 ${sp.c === c.slug ? "bg-mist font-semibold" : "hover:underline"}`}>{c.name}</Link>)}
    </nav>
    <div className="mt-6">{error ? <p role="alert" className="rounded-lg bg-red-50 p-4 text-red-800">Fixtures could not be loaded. Please try again shortly.</p> : <Listings fixtures={fixtures ?? []} />}</div>
  </>);
}
