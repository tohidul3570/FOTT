import { revalidatePath } from "next/cache";
import { syncFixtures } from "@/lib/sync";
export const maxDuration = 300;
export async function GET(req: Request) {
  if (req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return new Response("Unauthorized", { status: 401 });
  const r = await syncFixtures();
  revalidatePath("/", "layout");
  return Response.json(r, { status: r.ok ? 200 : 207 });
}
