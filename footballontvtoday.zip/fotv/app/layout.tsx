import "./globals.css";
import Link from "next/link";
import type { Metadata } from "next";
const site = process.env.NEXT_PUBLIC_SITE_URL ?? "https://footballontvtoday.com";
export const metadata: Metadata = { metadataBase: new URL(site), title: { default: "Football on TV Today – UK Football TV Guide", template: "%s | Football On TV Today" }, description: "Find out which football matches are on TV today in the UK, including kick-off times, live broadcasters and upcoming fixtures.", openGraph: { siteName: "Football On TV Today", type: "website" }, alternates: { canonical: "/" } };
const nav = [["/", "Today"], ["/?d=tomorrow", "Tomorrow"], ["/premier-league-on-tv", "Competitions"], ["/channels", "TV Channels"], ["/search", "Search"]];
export default function Root({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body className="min-h-screen">
    <header className="border-b border-line"><div className="mx-auto max-w-5xl px-4 py-3 flex flex-wrap items-center gap-x-6 gap-y-2">
      <Link href="/" className="text-lg font-extrabold tracking-tight">Football On <span className="text-pitch">TV</span> Today</Link>
      <nav aria-label="Main" className="flex gap-4 text-sm font-medium">{nav.map(([h, l]) => <Link key={h} href={h} className="hover:text-pitch">{l}</Link>)}</nav>
    </div></header>
    <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
    <footer className="border-t border-line mt-12 py-6 text-sm text-ink/70 text-center">Listings only – we do not stream football. Broadcast details are shown only when confirmed.</footer>
  </body></html>);
}
