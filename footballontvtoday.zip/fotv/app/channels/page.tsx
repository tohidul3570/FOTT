import Link from "next/link";
import { db } from "@/lib/db";
export const revalidate = 600; export const metadata = { title: "UK TV channels showing football" };
export default async function Channels() {
  const { data } = await db().from("broadcasters").select("slug,name,description,fixture_broadcasts!inner(id)").eq("fixture_broadcasts.status", "confirmed");
  return <><h1 className="text-3xl font-extrabold">TV channels</h1><ul className="mt-4 grid gap-3 sm:grid-cols-2">{data?.map(b => <li key={b.slug} className="rounded-lg border border-line p-4"><Link href={`/${b.slug}`} className="font-bold hover:text-pitch">{b.name}</Link><p className="text-sm text-ink/70">{b.description}</p></li>)}</ul>{!data?.length && <p className="mt-4 rounded bg-mist p-4">No channels with confirmed football listings yet.</p>}</>;
}
