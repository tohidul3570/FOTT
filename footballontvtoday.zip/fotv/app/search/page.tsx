import { db, FIXTURE_SELECT } from "@/lib/db";
import { Listings } from "../components";
export const metadata = { title: "Search football on TV", robots: { index: false } };
export default async function Search({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams; const sb = db(); let fx: any[] = [];
  if (q && q.length > 1) { const { data: t } = await sb.from("teams").select("id").ilike("name", `%${q.replace(/[%,()]/g, "")}%`).limit(20); const ids = (t ?? []).map(x => x.id).join(",");
    if (ids) fx = (await sb.from("fixtures").select(FIXTURE_SELECT).eq("published", true).gte("kickoff", new Date().toISOString()).or(`home_id.in.(${ids}),away_id.in.(${ids})`).order("kickoff").limit(40)).data ?? []; }
  return <><h1 className="text-3xl font-extrabold">Search</h1><form className="my-4 flex gap-2"><input name="q" defaultValue={q} placeholder="Team name" className="flex-1 rounded border border-line p-2" /><button className="rounded bg-ink px-4 text-white">Search</button></form>{q ? <Listings fixtures={fx} /> : <p>Enter a team name to find upcoming televised matches.</p>}</>;
}
