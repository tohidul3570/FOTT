import { notFound } from "next/navigation";
import { db, FIXTURE_SELECT } from "@/lib/db";
import { Listings } from "../components";
export const revalidate = 600;
// Handles /premier-league-on-tv (competition) and /sky-sports-football (broadcaster); only real DB rows render.
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const sb = db(); const now = new Date().toISOString();
  if (slug.endsWith("-on-tv")) {
    const { data: c } = await sb.from("competitions").select("id,name,intro").eq("slug", slug.slice(0, -6)).eq("enabled", true).maybeSingle(); if (!c) notFound();
    const { data: f } = await sb.from("fixtures").select(FIXTURE_SELECT).eq("competition_id", c.id).gte("kickoff", now).order("kickoff").limit(60);
    return <><h1 className="text-3xl font-extrabold">{c.name} on TV</h1><p className="my-3 max-w-2xl">{c.intro ?? `Upcoming ${c.name} fixtures with UK kick-off times and confirmed TV channels.`}</p><Listings fixtures={(f as any) ?? []} /></>;
  }
  const { data: b } = await sb.from("broadcasters").select("id,name,description").eq("slug", slug).maybeSingle(); if (!b) notFound();
  const { data: f } = await sb.from("fixtures").select(FIXTURE_SELECT.replace("broadcasts:fixture_broadcasts(", "broadcasts:fixture_broadcasts!inner(")).eq("fixture_broadcasts.broadcaster_id", b.id).eq("fixture_broadcasts.status", "confirmed").gte("kickoff", now).order("kickoff").limit(60);
  return <><h1 className="text-3xl font-extrabold">{b.name}: football on TV</h1>{b.description && <p className="my-3 max-w-2xl">{b.description}</p>}<Listings fixtures={(f as any) ?? []} /></>;
}
