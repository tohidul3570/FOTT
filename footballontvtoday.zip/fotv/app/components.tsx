import Link from "next/link";
import { ukTime } from "@/lib/db";
const Logo = ({ src, alt, s = 28 }: { src?: string | null; alt: string; s?: number }) => src ? <img src={src} alt={alt} width={s} height={s} loading="lazy" className="object-contain" style={{ width: s, height: s }} /> : <span aria-hidden className="grid place-items-center rounded-full bg-mist text-xs font-bold" style={{ width: s, height: s }}>{alt[0]}</span>;
export function MatchCard({ f }: { f: any }) {
  const conf = (f.broadcasts ?? []).filter((b: any) => b.status === "confirmed");
  return (<li className="flex items-center gap-3 border-b border-line py-3 last:border-0">
    <time dateTime={f.kickoff} className="w-14 shrink-0 text-lg font-bold text-pitch">{ukTime(f.kickoff)}</time>
    <Link href={`/match/${f.slug}`} className="flex-1 min-w-0 hover:underline">
      <span className="flex items-center gap-2 font-semibold"><Logo src={f.home?.logo} alt={f.home?.name} />{f.home?.name}</span>
      <span className="flex items-center gap-2 font-semibold mt-1"><Logo src={f.away?.logo} alt={f.away?.name} />{f.away?.name}</span>
    </Link>
    <div className="text-right text-sm">{conf.length ? conf.map((b: any, i: number) => <Link key={i} href={`/${b.broadcaster.slug}`} className="flex items-center justify-end gap-2 font-medium hover:text-pitch">{b.channel_name ?? b.broadcaster.name}<Logo src={b.broadcaster.logo} alt={b.broadcaster.name} s={22} /></Link>) : <span className="text-ink/60">TV coverage not confirmed</span>}</div>
  </li>);
}
export function Listings({ fixtures }: { fixtures: any[] }) {
  if (!fixtures.length) return <p className="rounded-lg bg-mist p-6 text-center">No fixtures found for this selection. Try another date or competition.</p>;
  const g = new Map<string, any[]>(); fixtures.forEach(f => g.set(f.competition.name, [...(g.get(f.competition.name) ?? []), f]));
  return <>{[...g].sort((a, b) => a[1][0].competition.priority - b[1][0].competition.priority).map(([n, list]) => (
    <section key={n} className="mb-6"><h2 className="flex items-center gap-2 rounded-t-lg bg-ink px-4 py-2 text-white font-bold"><Logo src={list[0].competition.logo} alt={n} s={22} />{n}</h2>
      <ul className="rounded-b-lg border border-t-0 border-line px-4">{list.map(f => <MatchCard key={f.id} f={f} />)}</ul></section>))}</>;
}
