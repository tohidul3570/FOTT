"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { admin } from "@/lib/db";
import { authClient, requireAdmin } from "@/lib/auth";
import { syncFixtures } from "@/lib/sync";
const s = (f: FormData, k: string) => (String(f.get(k) ?? "").trim() || null);
const done = () => { revalidatePath("/", "layout"); redirect("/admin"); };
export async function signIn(f: FormData) {
  const { error } = await (await authClient()).auth.signInWithPassword({ email: s(f, "email")!, password: s(f, "password")! });
  redirect(error ? "/admin/login?e=bad" : "/admin");
}
export async function signOut() { await (await authClient()).auth.signOut(); redirect("/admin/login"); }
export async function runSync() { await requireAdmin(); await syncFixtures(); done(); }
export async function addBroadcaster(f: FormData) {
  await requireAdmin(); const name = s(f, "name")!;
  await admin().from("broadcasters").upsert({ name, slug: s(f, "slug") ?? name.toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-football", logo: s(f, "logo"), description: s(f, "description") }, { onConflict: "slug" }); done();
}
export async function assign(f: FormData) {
  await requireAdmin();
  await admin().from("fixture_broadcasts").upsert({ fixture_id: Number(f.get("fixture_id")), broadcaster_id: Number(f.get("broadcaster_id")), channel_name: s(f, "channel_name") ?? "", coverage: s(f, "coverage"), status: s(f, "status") ?? "confirmed", source: s(f, "source"), verified_at: new Date().toISOString() }, { onConflict: "fixture_id,broadcaster_id,channel_name" }); done();
}
export async function unassign(f: FormData) { await requireAdmin(); await admin().from("fixture_broadcasts").delete().eq("id", Number(f.get("id"))); done(); }
export async function updateFixture(f: FormData) {
  await requireAdmin(); const k = s(f, "kickoff");
  await admin().from("fixtures").update({ ...(k && { kickoff: new Date(k).toISOString() }), status: s(f, "status") ?? "NS", manual_override: true, updated_at: new Date().toISOString() }).eq("id", Number(f.get("id"))); done();
}
export async function deleteFixture(f: FormData) { await requireAdmin(); await admin().from("fixtures").delete().eq("id", Number(f.get("id"))); done(); }
export async function toggleComp(f: FormData) { await requireAdmin(); await admin().from("competitions").update({ enabled: f.get("enabled") === "true" }).eq("id", Number(f.get("id"))); done(); }
export async function saveIntro(f: FormData) { await requireAdmin(); await admin().from("competitions").update({ intro: s(f, "intro"), priority: Number(f.get("priority") ?? 100) }).eq("id", Number(f.get("id"))); done(); }
