import { admin, db, ukTime, ukDay, dayRange, FIXTURE_SELECT } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import * as A from "./actions";
export const dynamic = "force-dynamic";
const inp = "rounded border border-line px-2 py-1 text-sm";
const btn = "rounded bg-ink px-3 py-1 text-sm font-semibold text-white";
const Hid = ({ n, v }: { n: string; v: any }) => <input type="hidden" name={n} value={v} />;
export default async function Admin({ searchParams }: { searchParams: Promise<{ c?: string; q?: string }> }) {
  await requireAdmin(); const sp = await searchParams; const sb = admin(); const now = new Date().toISOString();
  const today = dayRange(ukDay(new Date())); const week = new Date(Date.now() + 7 * 864e5).toISOString();
  const cnt = async (fn: (q: any) => any) => (await fn(sb.from("fixtures").select("id", { count: "exact", head: true }).gte("kickoff", now))).count ?? 0;
  const [upcoming, todayN, weekN, withTv] = await Promise.all([cnt(q => q), cnt(q => q.lt("kickoff", today.to)), cnt(q => q.lt("kickoff", week)),
    sb.from("fixture_broadcasts").select("fixture_id,fixtures!inner(kickoff)", { count: "exact", head: true }).eq("status", "confirmed").gte("fixtures.kickoff", now).then(r => r.count ?? 0)]);
  const [{ data: comps }, { data: bcs }, { data: logs }] = await Promise.all([sb.from("competitions").select("*").order("priority"), sb.from("broadcasters").select("id,name").order("name"), sb.from("sync_logs").select("*").order("started_at", { ascending: false }).limit(8)]);
  let q = sb.from("fixtures").select(FIXTURE_SELECT.replace("broadcasts:fixture_broadcasts(", "broadcasts:fixture_broadcasts(id,")).gte("kickoff", now).order("kickoff").limit(40);
  const cid = comps?.find(c => c.slug === sp.c)?.id; if (cid) q = q.eq("competition_id", cid);
  if (sp.q) { const { data: t } = await sb.from("teams").select("id").ilike("name", `%${sp.q}%`); const ids = (t ?? []).map(x => x.id).join(",") || "0"; q = q.or(`home_id.in.(${ids}),away_id.in.(${ids})`); }
  const { data: fx } = await q; const last = logs?.find(l => l.ok);
  return (<div className="space-y-8">
    <div className="flex items-center justify-between"><h1 className="text-3xl font-extrabold">Admin</h1><form action={A.signOut}><button className="text-sm underline">Sign out</button></form></div>
    <section><h2 className="mb-2 text-xl font-bold">Overview</h2>
      <dl className="grid grid-cols-2 gap-3 sm:grid-cols-5">{([["Upcoming", upcoming], ["Today", todayN], ["Next 7 days", weekN], ["Confirmed TV rows", withTv], ["Awaiting TV", Math.max(upcoming - withTv, 0)]] as const).map(([l, n]) => <div key={l} className="rounded-lg bg-mist p-3"><dt className="text-xs">{l}</dt><dd className="text-2xl font-bold text-pitch">{n}</dd></div>)}</dl>
      <p className="mt-3 text-sm">Last successful sync: {last ? new Date(last.started_at).toLocaleString("en-GB", { timeZone: "Europe/London" }) : "never"}. <form action={A.runSync} className="inline"><button className={btn}>Sync now</button></form></p>
      <table className="mt-2 w-full text-sm"><tbody>{logs?.map(l => <tr key={l.id} className="border-t border-line"><td>{new Date(l.started_at).toLocaleString("en-GB", { timeZone: "Europe/London" })}</td><td>{l.ok ? "OK" : "Failed"}</td><td>{l.fixtures_upserted} fixtures, {l.rescheduled} rescheduled, {l.api_calls} API calls</td><td className="text-red-700">{l.error}</td></tr>)}</tbody></table></section>
    <section><h2 className="mb-2 text-xl font-bold">Fixtures</h2>
      <form className="mb-3 flex flex-wrap gap-2"><input name="q" defaultValue={sp.q} placeholder="Team name" className={inp} /><select name="c" defaultValue={sp.c ?? ""} className={inp}><option value="">All competitions</option>{comps?.map(c => <option key={c.id} value={c.slug}>{c.name}</option>)}</select><button className={btn}>Filter</button></form>
      {!fx?.length && <p className="rounded bg-mist p-4">No upcoming fixtures. Run a sync or change the filter.</p>}
      {fx?.map((f: any) => (<div key={f.id} className="mb-3 rounded-lg border border-line p-3">
        <p className="font-semibold">{f.home.name} vs {f.away.name} <span className="font-normal text-ink/70">· {f.competition.name} · {ukTime(f.kickoff)}</span></p>
        {f.broadcasts.map((b: any) => <form key={b.id} action={A.unassign} className="mt-1 text-sm"><Hid n="id" v={b.id} />{b.channel_name || b.broadcaster.name} ({b.status}) <button className="text-red-700 underline">Remove</button></form>)}
        <form action={A.assign} className="mt-2 flex flex-wrap gap-2"><Hid n="fixture_id" v={f.id} /><select name="broadcaster_id" required className={inp}>{bcs?.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}</select><input name="channel_name" placeholder="Channel e.g. Main Event" className={inp} /><input name="source" placeholder="Source" className={inp} /><select name="status" className={inp}><option>confirmed</option><option>unconfirmed</option></select><button className={btn}>Assign</button></form>
        <form action={A.updateFixture} className="mt-2 flex flex-wrap gap-2"><Hid n="id" v={f.id} /><input type="datetime-local" name="kickoff" className={inp} aria-label="New kick-off (your local time)" /><input name="status" defaultValue={f.status} className={`${inp} w-16`} /><button className={btn}>Correct</button></form>
        <form action={A.deleteFixture} className="mt-1"><Hid n="id" v={f.id} /><button className="text-xs text-red-700 underline">Delete fixture</button></form></div>))}</section>
    <section><h2 className="mb-2 text-xl font-bold">Broadcasters</h2>
      <form action={A.addBroadcaster} className="flex flex-wrap gap-2"><input name="name" required placeholder="Name" className={inp} /><input name="slug" placeholder="URL slug (sky-sports-football)" className={inp} /><input name="logo" placeholder="Logo URL" className={inp} /><input name="description" placeholder="Description" className={inp} /><button className={btn}>Save broadcaster</button></form>
      <p className="mt-2 text-sm">{bcs?.map(b => b.name).join(", ") || "None yet."}</p></section>
    <section><h2 className="mb-2 text-xl font-bold">Competitions</h2>
      {comps?.map(c => (<div key={c.id} className="mb-2 flex flex-wrap items-center gap-2 border-t border-line pt-2"><span className="w-44 font-medium">{c.name}</span>
        <form action={A.toggleComp}><Hid n="id" v={c.id} /><Hid n="enabled" v={String(!c.enabled)} /><button className={btn}>{c.enabled ? "Disable" : "Enable"}</button></form>
        <form action={A.saveIntro} className="flex flex-1 gap-2"><Hid n="id" v={c.id} /><input name="priority" type="number" defaultValue={c.priority} className={`${inp} w-16`} aria-label="Priority" /><input name="intro" defaultValue={c.intro ?? ""} placeholder="SEO introduction" className={`${inp} flex-1`} /><button className={btn}>Save</button></form></div>))}</section>
  </div>);
}
