import { signIn } from "../actions";
export default async function Login({ searchParams }: { searchParams: Promise<{ e?: string }> }) {
  const { e } = await searchParams;
  return (<form action={signIn} className="mx-auto max-w-sm space-y-3"><h1 className="text-2xl font-extrabold">Admin sign in</h1>
    {e && <p role="alert" className="rounded bg-red-50 p-2 text-sm text-red-800">{e === "forbidden" ? "This account is not an administrator." : "Email or password is incorrect."}</p>}
    <input name="email" type="email" required placeholder="Email" className="w-full rounded border border-line p-2" />
    <input name="password" type="password" required placeholder="Password" className="w-full rounded border border-line p-2" />
    <button className="w-full rounded bg-ink py-2 font-semibold text-white">Sign in</button></form>);
}
