import Link from "next/link";
export default function NF() { return <div className="py-16 text-center"><h1 className="text-3xl font-extrabold">Page not found</h1><p className="mt-2">That page doesn't exist or the fixture has been removed.</p><Link href="/" className="mt-4 inline-block text-pitch underline">See football on TV today</Link></div>; }
