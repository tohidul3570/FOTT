create table competitions(id serial primary key, api_id int unique not null, slug text unique not null, name text not null, logo text, priority int default 100, enabled boolean default true, season int default 2026, intro text, updated_at timestamptz default now());
create table teams(id serial primary key, api_id int unique not null, slug text not null, name text not null, logo text, updated_at timestamptz default now());
create table fixtures(id serial primary key, api_id int unique, slug text unique not null, competition_id int references competitions(id) on delete cascade, home_id int references teams(id), away_id int references teams(id), kickoff timestamptz not null, status text default 'NS', home_score int, away_score int, venue text, manual_override boolean default false, published boolean default true, updated_at timestamptz default now());
create index on fixtures(kickoff); create index on fixtures(competition_id, kickoff);
create table broadcasters(id serial primary key, slug text unique not null, name text not null, logo text, description text);
create table fixture_broadcasts(id serial primary key, fixture_id int references fixtures(id) on delete cascade, broadcaster_id int references broadcasters(id) on delete cascade, channel_name text, starts_at timestamptz, coverage text, status text not null default 'confirmed' check(status in('confirmed','unconfirmed')), source text, verified_at timestamptz, unique(fixture_id,broadcaster_id,channel_name));
create table sync_logs(id serial primary key, started_at timestamptz default now(), ok boolean, fixtures_upserted int, rescheduled int, api_calls int, error text);
create table site_settings(key text primary key, value text);
create table admin_users(user_id uuid primary key references auth.users(id));
create function is_admin() returns boolean language sql security definer as $$ select exists(select 1 from admin_users where user_id=auth.uid()) $$;
do $$ declare t text; begin foreach t in array array['competitions','teams','fixtures','broadcasters','fixture_broadcasts','site_settings'] loop
 execute format('alter table %I enable row level security',t);
 execute format('create policy "public read" on %I for select using (true)',t);
 execute format('create policy "admin write" on %I for all using (is_admin()) with check (is_admin())',t); end loop; end $$;
alter table sync_logs enable row level security; create policy "admin read" on sync_logs for select using (is_admin());
alter table admin_users enable row level security; create policy "self" on admin_users for select using (user_id=auth.uid());
-- Sync writes use the service role key (bypasses RLS). Seed with API-Football league ids:
insert into competitions(api_id,slug,name,priority) values
(39,'premier-league','Premier League',1),(45,'fa-cup','FA Cup',2),(2,'champions-league','UEFA Champions League',3),(3,'europa-league','UEFA Europa League',4),(848,'conference-league','UEFA Conference League',5),(140,'la-liga','La Liga',6),(135,'serie-a','Serie A',7),(78,'bundesliga','Bundesliga',8),(61,'ligue-1','Ligue 1',9),(40,'championship','EFL Championship',10),(48,'efl-cup','EFL Cup',11);
